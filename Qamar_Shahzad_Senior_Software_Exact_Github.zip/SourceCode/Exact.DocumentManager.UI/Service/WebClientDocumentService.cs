﻿using System;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using System.Text;
using DotNetOpenAuth.OAuth2;
using Exact.DocumentManager.UI.Domain;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace Exact.DocumentManager.UI.Service
{
	public class WebClientDocumentService : WebClientServiceBase
	{
		#region Properties

		public static Uri ServiceUri
		{
            get { return new Uri(BaseUri, string.Format("api/v1/{0}/documents/", Me.CurrentCompany)); }
		}

		#endregion

		#region Constructor

        public WebClientDocumentService(IAuthorizationState authorizationState)
            : base(authorizationState)
		{
		}

		#endregion

		#region Public Methods

        public void Create(Document document)
		{
            try
            {
                WebClient.UploadString(ResourceUri(), "POST", FormatJson(document));
            }
            catch (WebException ex)
                {
                    var resp = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();

                    dynamic obj = JsonConvert.DeserializeObject(resp);
                    var messageFromServer = obj.error.message;
                }
		}

        public Document Read(Guid documentId)
		{
            string jsonResponse = WebClient.DownloadString(ResourceUri(documentId));

            Document document = ParseJsonSingle(jsonResponse);
            return document;
		}

        public void Update(Document document)
		{
			WebClient.UploadString(
                ResourceUri(document.Id),
				"PUT",
                FormatJson(document));
		}

        public void Delete(Guid documentId)
		{
			WebClient.UploadString(
                ResourceUri(documentId),
				"DELETE",
				"");
		}

        public IEnumerable<Document> GetList(string filter)
		{
			var uriBuilder = new UriBuilder(ResourceUri());

            var sb = new StringBuilder("$select=ID,Subject, Body,Type, Account, Category");
            sb.AppendFormat("&$filter=substringof('{0}',Subject)+eq+true+or+substringof('{0}',Body)+eq+true", "");
            sb.Append("&$orderby=Subject");
			uriBuilder.Query = sb.ToString();

			string jsonResponse = this.WebClient.DownloadString(uriBuilder.Uri);
            IEnumerable<Document> documents = ParseJsonList(jsonResponse);

            return documents;
		}

		#endregion

		#region Private Methods

		private Uri ResourceUri()
		{
			return ResourceUri(null);
		}

		private Uri ResourceUri(Guid? documentId)
		{
			Uri serviceUri = ServiceUri;
            if (documentId != null)
			{
                string resourceLocation = String.Format("Documents(guid'{0}')", documentId);
				return new Uri(serviceUri, resourceLocation);
			}
            return new Uri(serviceUri, "Documents");
		}

        private string FormatJson(Document document)
		{
            var sb = new StringBuilder();
            const string jsonFormat = "\"{0}\":\"{1}\"";

            sb.Append("{");
            sb.AppendFormat(jsonFormat, "Subject", document.Subject);
            sb.Append(",");
            sb.AppendFormat(jsonFormat, "Body", document.Body);
            sb.Append(",");
            sb.AppendFormat(jsonFormat, "Type", document.Type);
            sb.Append(",");
            sb.AppendFormat(jsonFormat, "Account", document.Account);
            sb.Append(",");
            sb.AppendFormat(jsonFormat, "Category", document.Category);
            sb.Append("}");

            return sb.ToString();
		}

        private Document ConvertJsonDictionary(Dictionary<string, object> documentJson)
		{
            Document document = null;

            if ((documentJson != null) && (documentJson.Count > 0))
			{

                string subject = (string)documentJson["Subject"];
                string body = (string)documentJson["Body"];

                if (!string.IsNullOrEmpty(subject))
                {
                    if (subject.Length > 50)
                    {
                        subject = subject.Substring(0, 50) + "...";
                    }
                }

                if (!string.IsNullOrEmpty(body))
                {
                    body = body.Replace("<html>", "").Replace("</html>", "");
                    if (body.Length > 50)
                    {
                        body = body.Substring(0, 50) + "...";
                    }
                }
                
                

                document = new Document
					{
                        Id = new Guid((string)documentJson["ID"]),
                        Account = new Guid((string)documentJson["Account"]),
                        Category = new Guid((string)documentJson["Category"]),
                        Subject = subject,
                        Body = body,
                        Type = (int)documentJson["Type"]
					};
			}

            return document;
		}

        private IEnumerable<Document> ParseJsonList(string jsonString)
		{
			var serializer = new JavaScriptSerializer();
			var jsonObject = serializer.DeserializeObject(jsonString) as Dictionary<string, object>;
			var document = (Dictionary<string, object>)jsonObject["d"];
			var resultList = (Array)document["results"];

            var documents = new List<Document>();
            foreach (Dictionary<string, object> documentJson in resultList)
			{
                documents.Add(ConvertJsonDictionary(documentJson));
			}
            return documents;
		}

        private Document ParseJsonSingle(string jsonString)
		{
			var serializer = new JavaScriptSerializer();
			var jsonObject = serializer.DeserializeObject(jsonString) as Dictionary<string, object>;
            var documentJson = (Dictionary<string, object>)jsonObject["d"];

            return ConvertJsonDictionary(documentJson);
		}

		#endregion

	}
}