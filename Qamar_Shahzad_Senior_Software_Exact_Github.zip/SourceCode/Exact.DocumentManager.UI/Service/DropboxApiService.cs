﻿using Exact.DocumentManager.UI.Domain;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Exact.DocumentManager.UI.Service
{
    public class DropboxApiService
    {
        public async Task<List<DropboxFile>> GetList()
        {
            List<DropboxFile> dropboxFiles = new List<DropboxFile>();

            using (var client = DropboxApiClient.GetAuthenticatedClient())
            {
                var list = await client.Files.ListFolderAsync(string.Empty);

                foreach (var item in list.Entries.Where(i => i.IsFile))
                {
                    DropboxFile dropboxFile = new DropboxFile();
                    dropboxFile.Id = item.AsFile.Id.Replace("id:","");
                    dropboxFile.Name = item.AsFile.Name;
                    dropboxFile.Rev = item.AsFile.Rev;
                    dropboxFile.Size = item.AsFile.Size;
                    dropboxFile.DateModified = item.AsFile.ServerModified;

                    dropboxFiles.Add(dropboxFile);

                }
            }
            return dropboxFiles;
        }

        public async Task<DropboxFile> AddFile(string subject, string body)
        {
            DropboxFile dropboxFile = new DropboxFile();

            using (var client = DropboxApiClient.GetAuthenticatedClient())
            {

                using (var mem = new MemoryStream(Encoding.UTF8.GetBytes(body)))
                {
                    var upload = await client.Files.UploadAsync("/" + subject, body: mem);

                    dropboxFile.Id = upload.AsFile.Id.Replace("id:", "");
                    dropboxFile.Name = upload.AsFile.Name;
                    dropboxFile.Rev = upload.AsFile.Rev;
                    dropboxFile.Size = upload.AsFile.Size;
                    dropboxFile.DateModified = upload.AsFile.ServerModified;

                }
            }

            return dropboxFile;
        }

    }
}