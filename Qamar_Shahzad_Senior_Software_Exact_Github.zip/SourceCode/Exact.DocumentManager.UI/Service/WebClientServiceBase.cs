﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Web.Configuration;
using System.Web.Script.Serialization;
using DotNetOpenAuth.OAuth2;

namespace Exact.DocumentManager.UI.Service
{
	public class WebClientServiceBase : IDisposable
	{
		#region Fields

		private WebClient _webClient;
		private readonly IAuthorizationState _authorizationState;

		#endregion

		#region Properties

		protected static Uri BaseUri
		{
			get
			{
                var baseUri = WebConfigurationManager.AppSettings["ExactBaseUri"];
				return new Uri(baseUri.EndsWith("/") ? baseUri : baseUri + "/");
			}
		}

		protected WebClient WebClient
		{
			get
			{
				if (_webClient == null)
				{
					_webClient = new WebClient();

					_webClient.Headers.Add("Content-type", "application/json");
					_webClient.Headers.Add("Accept", "application/json");

					if (_authorizationState != null)
					{
						_webClient.Headers.Add("Authorization", "Bearer " + _authorizationState.AccessToken);
					}
				}
				return _webClient;
			}
		}

		#endregion

		#region Constructor

		public WebClientServiceBase(IAuthorizationState authorizationState)
		{
			_authorizationState = authorizationState;
		}

		#endregion

		#region IDisposable

		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		protected virtual void Dispose(bool disposing)
		{
			if (disposing)
			{
				// dispose managed resources
				if (_webClient != null)
				{
					_webClient.Dispose();
				}
			}
		}

		#endregion
	}
}