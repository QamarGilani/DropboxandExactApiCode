﻿using Dropbox.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace Exact.DocumentManager.UI.Service
{
    public class DropboxApiClient
    {
        
        public static DropboxClient GetAuthenticatedClient()
        {
            return new DropboxClient(WebConfigurationManager.AppSettings["DropboxAppAccessToken"], new DropboxClientConfig("Exact.DocumentManager.UI"));
        }
    }
}