﻿namespace Exact.DocumentManager.UI.Domain
{
    public static class Me
    {
        public static int CurrentCompany { get; set; }
    }
}