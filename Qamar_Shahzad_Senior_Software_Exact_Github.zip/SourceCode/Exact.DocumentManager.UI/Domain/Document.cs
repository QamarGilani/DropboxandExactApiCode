﻿using System;

namespace Exact.DocumentManager.UI.Domain
{
    public class Document
    {
        public Guid Id { get; set; }
        public Guid Account { get; set; }
        public Guid Category { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public int Type { get; set; }
    }
}