﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Exact.DocumentManager.UI.Domain
{
    public class DropboxFile
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Rev { get; set; }
        public ulong  Size { get; set; }
        public DateTime DateModified { get; set; }
    }
}