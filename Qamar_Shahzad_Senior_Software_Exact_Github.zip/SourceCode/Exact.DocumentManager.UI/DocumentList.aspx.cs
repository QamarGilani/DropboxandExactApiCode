﻿using Exact.DocumentManager.UI.Domain;
using Exact.DocumentManager.UI.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Exact.DocumentManager.UI
{
    public partial class DocumentList : Page
    {
        private ExactOnlineOAuthClient _OAuthClient = new ExactOnlineOAuthClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (AuthorizeClient())
            {
                if (!IsPostBack)
                {
                    LoadDropboxFiles();
                    LoadExactDocument();
                }
            }
        }

        private Boolean AuthorizeClient()
        {
            if (Session.Keys.Count == 0)
            {
                Session["Init"] = 0;
            }

            _OAuthClient.Authorize(Session, "DocumentList.aspx");

            return (_OAuthClient.Authorization != null);
        }

        private async void LoadDropboxFiles()
        {
            var dropboxApiService = new DropboxApiService();

            dgDropboxFile.DataSource = await dropboxApiService.GetList();

            dgDropboxFile.DataBind();
        }

        private void LoadExactDocument()
        {
            using (var documentService = new WebClientDocumentService(_OAuthClient.Authorization))
            {
                dgExactDocument.DataSource = documentService.GetList(Guid.Empty.ToString());
            }

            dgExactDocument.DataBind();
        }

        protected void DeleteRecord(object sender, GridViewDeleteEventArgs e)
        {

            string Id = dgExactDocument.DataKeys[e.RowIndex].Value.ToString();
            using (var documentService = new WebClientDocumentService(_OAuthClient.Authorization))
            {
                documentService.Delete(Guid.Parse(Id));
            }
            LoadExactDocument();

        }


    }
}