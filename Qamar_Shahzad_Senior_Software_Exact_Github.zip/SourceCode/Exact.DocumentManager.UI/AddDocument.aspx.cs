﻿using Exact.DocumentManager.UI.Domain;
using Exact.DocumentManager.UI.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Exact.DocumentManager.UI
{
    public partial class AddDocument : Page
    {
        private ExactOnlineOAuthClient _OAuthClient = new ExactOnlineOAuthClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            AuthorizeClient();
        }

        private Boolean AuthorizeClient()
        {
            if (Session.Keys.Count == 0)
            {
                Session["Init"] = 0;
            }

            _OAuthClient.Authorize(Session, "AddDocument.aspx");

            return (_OAuthClient.Authorization != null);
        }

        protected void btnAddNewFile_Click(object sender, EventArgs e)
        {
            AddDropboxFile();

        }

        private async void AddDropboxFile()
        {
            var dropboxApiService = new DropboxApiService();
            string subject = this.txtFileName.Text + "_" + DateTime.Now.Ticks.ToString();
            string body = txtFileDetail.Text;

            DropboxFile dropboxFile = await dropboxApiService.AddFile(subject, body);

            using (var documentService = new WebClientDocumentService(_OAuthClient.Authorization))
            {
                AddExactDocument(documentService,subject,body);
            }

        }

        private void AddExactDocument(WebClientDocumentService documentService, string subject, string body)
        {
            var newDocument = new Document
            {
                Subject = subject,
                Body = body,
                Type = 149,
                Account = Guid.Parse("6bae5a5b-4f0d-49d5-bb8b-75341b38a747"),
                Category = Guid.Parse("90f98168-38ec-4ef7-876f-1eb5d3ba1863")
           };

            documentService.Create(newDocument);

            Response.Redirect("DocumentList.aspx");
        }

             
    }
}